/* global QUnit */

sap.ui.require(["com/gpbp/zs2dlogtable/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
