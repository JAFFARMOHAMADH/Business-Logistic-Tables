/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"comgpbp/zs2d_log_table/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});
