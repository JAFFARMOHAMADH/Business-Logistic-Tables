sap.ui.define([
	"comgpbp/zs2d_log_table/test/unit/controller/App.controller"
], function () {
	"use strict";
});
