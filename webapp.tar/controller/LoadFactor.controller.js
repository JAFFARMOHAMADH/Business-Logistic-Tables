sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/export/Spreadsheet",
    "sap/ui/unified/FileUploader",
    "sap/m/Dialog",
    "sap/m/Button",
    "com/gpbp/zs2dlogtable/excel_lib/jszip",
    "com/gpbp/zs2dlogtable/excel_lib/xlsx",
    "sap/m/MessageBox",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/Fragment",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    'sap/m/MessagePopover',
    'sap/m/MessageItem',
    'sap/m/MessageToast',
    'sap/m/SearchField',
    'sap/ui/model/type/String',
    'sap/ui/table/Column',
    'sap/m/Column',
    'sap/m/Text',
    'sap/m/Label'
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, Spreadsheet, FileUploader, Dialog, Button, jszip, xlsx, MessageBox, JSONModel, Fragment, Filter, FilterOperator, MessagePopover, MessageItem, MessageToast, SearchField, TypeString, UIColumn, MColumn, Text, Label) {
        "use strict";
        var oMessagePopover;
        return Controller.extend("com.gpbp.zs2dlogtable.controller.LoadFactor", {
            //Initializing local json model in initialization method
            onInit: function () {
                let oLocalModel = new JSONModel();
                this.getView().setModel(oLocalModel, "LocalModel");

                let oOperations = {
                    Value: "",
                    Upload: "",
                    Edit: false,
                    TableData: "",
                    Modify: "",
                    Create: "",
                    Error: false,
                    BlankCell: false
                };
                this.getView().getModel("LocalModel").setProperty("/Operation", oOperations);

                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.getRoute("RouteFactor").attachMatched(this._onRouteMatched, this);
            },

            // Checking user authoraization in routing event handler
            _onRouteMatched: function (oEvt) {
                this.getView().setBusy(true);
                this.getView().getModel("LocalModel").setProperty("/LoadData", []);
                this.getView().getModel("LocalModel").getProperty("/Operation").Error = false;
                this.getView().getModel("LocalModel").refresh(true);
                // User Auth check and setting buttons visibility
                this._getODataModel().read("/ETS_AUTH_CHECK", {
                    success: function (odata) {
                        if (odata.results[0].Access !== "X") {
                            this.getView().setBusy(false);
                            let oVisibility = {
                                Access: odata.results[0].Access
                            };
                            this.getView().getModel("LocalModel").setProperty("/Visibility", oVisibility);
                        } else {
                            this.getView().setBusy(false);
                            this.getOwnerComponent().getRouter().getTargets().display("NotFound");
                        }

                    }.bind(this),
                    error: function (error) {
                        this.getView().setBusy(false);
                        MessageBox.error(this._getText("authError"));
                    }.bind(this)
                });
            },

            // Method to download excel template
            onTemplate: function () {
                let aColumns = this._getTemplateColumns();

                let oSettings = {
                    workbook: { columns: aColumns },
                    dataSource: [{}],
                    fileName: 'Load Factor'
                };

                let oSheet = new Spreadsheet(oSettings);
                oSheet.build().finally(function () {
                    oSheet.destroy();
                });
            },

            // Method to export table data in excel format
            onExport: function () {
                let aColumns = this._getTemplateColumns(),
                    aRecords = this.getView().getModel("LocalModel").getProperty("/LoadData");

                let oSettings = {
                    workbook: { columns: aColumns },
                    dataSource: aRecords,
                    fileName: 'Load Factor'
                };

                let oSheet = new Spreadsheet(oSettings);
                oSheet.build().finally(function () {
                    oSheet.destroy();
                });
            },

            // Private method to generate excel columns
            _getTemplateColumns: function () {
                var aCols = [];

                /* 1. Add a simple text column */
                aCols.push({
                    label: 'Origin_Plant',
                    property: 'OriginPlant',
                    type: 'string'
                });
                aCols.push({
                    label: 'Mode_of_Transportation',
                    property: 'ModeofTransportation',
                    type: 'text'
                });
                aCols.push({
                    label: 'Shipping_Condition',
                    property: 'ShipmentType',
                    type: 'string'
                });
                aCols.push({
                    label: 'Equipment_Type',
                    property: 'EquipmentType',
                    type: 'string'
                });
                aCols.push({
                    label: 'Product_Sku',
                    property: 'ProductSku',
                    type: 'string'
                });
                aCols.push({
                    label: 'Quantity_on_Equipment',
                    property: 'QuantityonEquipment',
                    type: "Number"
                });
                aCols.push({
                    label: 'PUOM',
                    property: 'Puom',
                    type: 'string'
                });

                return aCols;
            },

            // Method to upload excel file
            onExcelUpload: function () {
                var oDomRef;
                var oUploadDialog = new Dialog({
                    draggable: false,
                    resizable: true,
                    title: this.getView().getModel("i18n").getResourceBundle().getText("uploadExcel")
                });

                // prepare the FileUploader control
                var oFileUploader = new FileUploader({
                    uploadUrl: "",
                    name: "simpleUploader",
                    tooltip: "Browse",
                    buttonText: "Browse",
                    fileType: ["xlsx"],
                    icon: "sap-icon://attachment",
                    uploadOnChange: false,
                    sendXHR: true,
                    useMultipart: false,
                    placeholder: "...",
                    style: "Emphasized",
                    change: function (oEvent) {
                        oDomRef = oEvent.getParameters('files').files[0];
                    },
                    headerParameters: [],
                    uploadProgress: function () {
                        this.getView().setBusy(true);
                    }

                }).addStyleClass("sapUiTinyMarginBeginEnd");

                // create a button to trigger the upload
                var oTriggerButton = new Button({
                    text: this.getView().getModel("i18n").getResourceBundle().getText("upload"),
                    press: function () {
                        if (oDomRef) {
                            oUploadDialog.close();
                            this.getView().setBusy(true);

                            var file = oDomRef;

                            var reader = new FileReader();
                            reader.onload = function (cFile) {
                                var data = cFile.target.result;
                                var workbook = XLSX.read(data, { type: 'binary' });

                                if (workbook.Strings.length > 0 && workbook.Strings[0].t === "Origin_Plant") {
                                    // reading excel data
                                    var aResult = [], aLoadData = [];
                                    workbook.SheetNames.forEach(function (sheetName) {
                                        var rObjArr = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);
                                        if (rObjArr.length > 0) {
                                            aResult = rObjArr;
                                        }
                                    });

                                    // filling the sheet data into local json model and updating table
                                    aResult.forEach((item) => {
                                        if (item.Mode_of_Transportation.length > 0 && item.Mode_of_Transportation.length === 1) {
                                            item.Mode_of_Transportation = "0" + item.Mode_of_Transportation;
                                        }

                                        let oLoadData = {
                                            OriginPlant: item.Origin_Plant,
                                            OriginPlantDescription: "",
                                            ModeofTransportation: item.Mode_of_Transportation,
                                            ModeofTransportationDescr: "",
                                            ShipmentType: item.Shipping_Condition,
                                            ShipmentTypeDescription: "",
                                            EquipmentType: item.Equipment_Type,
                                            EquipmentTypeDescription: "",
                                            ProductSku: item.Product_Sku,
                                            ProductSkuDescription: "",
                                            QuantityonEquipment: item.Quantity_on_Equipment,
                                            Puom: item.PUOM,
                                            flag_text: "X"
                                        }
                                        aLoadData.push(oLoadData);
                                    });

                                    // generating payload to post data
                                    let oPayload = {
                                        OPERATION: "V",
                                        MSG_TYPE: "",
                                        MESSAGE: "",
                                        LOAD_FACTOR: aLoadData
                                    };

                                    this._getODataModel().create("/ETS_HEADER", oPayload, {
                                        success: function (oData) {
                                            this.getView().getModel("LocalModel").setProperty("/LoadData", oData.LOAD_FACTOR.results);
                                            this.getView().getModel("LocalModel").getProperty("/Operation").Upload = "X";
                                            this.getView().getModel("LocalModel").getProperty("/Operation").TableData = "X";
                                            this.getView().getModel("LocalModel").getProperty("/Operation").Edit = false;
                                            this.getView().byId("_IDSmartInnerTable").getModel().refresh(true);

                                            if (oData.MSG_TYPE === "E") {
                                                this.getView().getModel("LocalModel").getProperty("/Operation").Error = true;
                                                this._getMessagePopover(oData.LOAD_FACTOR.results);
                                            }

                                            this.getView().getModel("LocalModel").refresh(true);
                                            this.getView().setBusy(false);
                                        }.bind(this),
                                        error: function (oError) {
                                            this.getView().setBusy(false);
                                            var sPattern = new RegExp("[{}]");
                                            var sSstrMatch = oError.responseText.match(sPattern);
                                            if (sSstrMatch) {
                                                var sMsg = JSON.parse(oError.responseText);
                                                MessageBox.error(sMsg.error.message.value);
                                            } else {
                                                MessageBox.error(oError.responseText);
                                            }
                                        }.bind(this)
                                    })
                                } else {
                                    this.getView().setBusy(false);
                                    MessageBox.error(this._getText("invalidTemplate"));
                                }
                            }.bind(this);

                            reader.onerror = function (ex) {
                                MessageBox.error(ex);
                                oUploadDialog.close();
                                this.getView().setBusy(false);
                            }.bind(this);

                            reader.readAsBinaryString(file);
                        } else {
                            this.getView().setBusy(false);
                            MessageBox.error(this._getText("fileError"));
                        }
                    }.bind(this)
                }).addStyleClass("sapUiTinyMarginBeginEnd");

                const oCloseBtn = new Button({
                    text: this.getView().getModel("i18n").getResourceBundle().getText("close"),
                    press: function () {
                        oUploadDialog.close();
                    }
                }).addStyleClass('sapUiTinyMarginEnd');

                oUploadDialog.addContent(oFileUploader);
                oUploadDialog.addContent();
                oUploadDialog.addContent(oTriggerButton);
                oUploadDialog.addContent(oCloseBtn);
                oUploadDialog.open();
            },

            // Method to get table data using filter values
            onSearch: function (oEvt) {
                this._removeErrorState();
                var aFilterbar = this.getView().byId("_IDSmartFilter"),
                    oItems = aFilterbar.getAllFiltersWithValues(true),
                    aFilter = [],
                    aFilters = [],
                    aFilter1 = [];

                oItems.forEach((item) => {
                    switch (item.getName()) {
                        case "OriginPlant":
                            var oToken = aFilterbar
                                .determineControlByFilterItem(item)
                                .getTokens(),
                                aFilter1 = [];
                            oToken.forEach((element) => {
                                if (element.data("range")) {
                                    var oProperty = element.data("range");

                                    aFilter1.push(
                                        new Filter({
                                            filters: [
                                                new Filter(
                                                    "OriginPlant",
                                                    FilterOperator[oProperty.operation],
                                                    oProperty.value1,
                                                    oProperty.value2
                                                ),
                                            ],
                                        })
                                    );
                                } else {
                                    if (element.data().row) {
                                        var value = element.data();
                                        aFilter1.push(
                                            new Filter({
                                                filters: [
                                                    new Filter(
                                                        "OriginPlant",
                                                        FilterOperator.EQ,
                                                        value.row.werks
                                                    ),
                                                ],
                                            })
                                        );
                                    } else if (element.getKey()) {
                                        aFilter1.push(
                                            new Filter({
                                                filters: [
                                                    new Filter(
                                                        "OriginPlant",
                                                        FilterOperator.EQ,
                                                        element.getKey()
                                                    ),
                                                ],
                                            })
                                        );
                                    }
                                }
                            });
                            if (aFilter1.length > 0) {
                                aFilter.push(
                                    new Filter({
                                        filters: aFilter1,
                                    })
                                );
                            }
                            break;
                        case "ModeofTransportation":
                            var oToken = aFilterbar
                                .determineControlByFilterItem(item)
                                .getTokens(),
                                aFilter1 = [];
                            oToken.forEach((element) => {
                                if (element.data("range")) {
                                    var oProperty = element.data("range");

                                    aFilter1.push(
                                        new Filter({
                                            filters: [
                                                new Filter(
                                                    "ModeofTransportation",
                                                    FilterOperator[oProperty.operation],
                                                    oProperty.value1,
                                                    oProperty.value2
                                                ),
                                            ],
                                        })
                                    );
                                } else {
                                    var value = element.data();
                                    aFilter1.push(
                                        new Filter({
                                            filters: [
                                                new Filter(
                                                    "ModeofTransportation",
                                                    FilterOperator.EQ,
                                                    value.row.vktra
                                                ),
                                            ],
                                        })
                                    );
                                }
                            });
                            if (aFilter1.length > 0) {
                                aFilter.push(
                                    new Filter({
                                        filters: aFilter1,
                                    })
                                );
                            }
                            break;
                        case "ShipmentType":
                            var oToken = aFilterbar
                                .determineControlByFilterItem(item)
                                .getTokens(),
                                aFilter1 = [];
                            oToken.forEach((element) => {
                                if (element.data("range")) {
                                    var oProperty = element.data("range");

                                    aFilter1.push(
                                        new Filter({
                                            filters: [
                                                new Filter(
                                                    "ShipmentType",
                                                    FilterOperator[oProperty.operation],
                                                    oProperty.value1,
                                                    oProperty.value2
                                                ),
                                            ],
                                        })
                                    );
                                } else {
                                    var value = element.data();
                                    aFilter1.push(
                                        new Filter({
                                            filters: [
                                                new Filter(
                                                    "ShipmentType",
                                                    FilterOperator.EQ,
                                                    value.row.vsart
                                                ),
                                            ],
                                        })
                                    );
                                }
                            });
                            if (aFilter1.length > 0) {
                                aFilter.push(
                                    new Filter({
                                        filters: aFilter1,
                                    })
                                );
                            }
                            break;
                        case "ProductSku":
                            var oToken = aFilterbar
                                .determineControlByFilterItem(item)
                                .getTokens(),
                                aFilter1 = [];
                            oToken.forEach((element) => {
                                if (element.data("range")) {
                                    var oProperty = element.data("range");

                                    aFilter1.push(
                                        new Filter({
                                            filters: [
                                                new Filter(
                                                    "ProductSku",
                                                    FilterOperator[oProperty.operation],
                                                    oProperty.value1,
                                                    oProperty.value2
                                                ),
                                            ],
                                        })
                                    );
                                } else {
                                    var value = element.data();
                                    aFilter1.push(
                                        new Filter({
                                            filters: [
                                                new Filter(
                                                    "ProductSku",
                                                    FilterOperator.EQ,
                                                    value.row.matnr
                                                ),
                                            ],
                                        })
                                    );
                                }
                            });
                            if (aFilter1.length > 0) {
                                aFilter.push(
                                    new Filter({
                                        filters: aFilter1,
                                    })
                                );
                            }
                            break;
                        case "EquipmentType":
                            var oToken = aFilterbar
                                .determineControlByFilterItem(item)
                                .getTokens(),
                                aFilter1 = [];
                            oToken.forEach((element) => {
                                if (element.data("range")) {
                                    var oProperty = element.data("range");

                                    aFilter1.push(
                                        new Filter({
                                            filters: [
                                                new Filter(
                                                    "EquipmentType",
                                                    FilterOperator[oProperty.operation],
                                                    oProperty.value1,
                                                    oProperty.value2
                                                ),
                                            ],
                                        })
                                    );
                                } else {
                                    var value = element.data();
                                    aFilter1.push(
                                        new Filter({
                                            filters: [
                                                new Filter(
                                                    "EquipmentType",
                                                    FilterOperator.EQ,
                                                    value.row.losp_id
                                                ),
                                            ],
                                        })
                                    );
                                }
                            });
                            if (aFilter1.length > 0) {
                                aFilter.push(
                                    new Filter({
                                        filters: aFilter1,
                                    })
                                );
                            }
                            break;
                        case "Puom":
                            var oToken = aFilterbar
                                .determineControlByFilterItem(item)
                                .getSelectedKeys(),
                                aFilter1 = [];
                            oToken.forEach((element) => {
                                aFilter1.push(
                                    new Filter({
                                        filters: [
                                            new Filter(
                                                "Puom",
                                                FilterOperator.EQ,
                                                element
                                            ),
                                        ],
                                    })
                                );
                            });
                            if (aFilter1.length > 0) {
                                aFilter.push(
                                    new Filter({
                                        filters: aFilter1,
                                    })
                                );
                            }
                            break;
                    }
                });

                aFilters.push(
                    new Filter({
                        filters: aFilter,
                        and: true,
                    })
                );

                this.getView().byId("_IDSmartTable").setBusy(true);
                let sServiceUrl = "/zcdsv_s2d_LOAD_FACTOR";

                let mParameters = {
                    filters: aFilters,
                    success: function (data) {
                        this.getView().getModel("LocalModel").setProperty("/LoadData", data.results);
                        this.getView().getModel("LocalModel").getProperty("/Operation").Upload = "";
                        this.getView().getModel("LocalModel").getProperty("/Operation").TableData = "X";
                        this.getView().getModel("LocalModel").getProperty("/Operation").Error = false;
                        this.getView().getModel("LocalModel").setProperty("/Messages", []);
                        this.getView().byId("_IDSmartInnerTable").getModel().refresh(true);
                        this.getView().getModel("LocalModel").refresh(true);
                        this.getView().byId("_IDSmartTable").setBusy(false);
                    }.bind(this),
                    error: function (oError) {
                        this.getView().byId("_IDSmartTable").setBusy(false);
                        var sPattern = new RegExp("[{}]");
                        var sSstrMatch = oError.responseText.match(sPattern);
                        if (sSstrMatch) {
                            var sMsg = JSON.parse(oError.responseText);
                            MessageBox.error(sMsg.error.message.value);
                        } else {
                            MessageBox.error(oError.responseText);
                        }
                    }.bind(this)
                };

                this._getODataModel().read(sServiceUrl, mParameters);
            },


            // Method to invoke dialog box for adding a record in table
            onAddRecord: function (oEvt) {
                this._openDialog();
            },

            // Method to make table data editable
            onEditRecord: function (oEvt) {
                this.getView().getModel("LocalModel").getProperty("/Operation").Edit = true;
                this.getView().getModel("LocalModel").refresh();
            },

            // Method to make table data readable
            onCancelEdit: function () {
                this.getView().getModel("LocalModel").getProperty("/Operation").Edit = false;
                this.getView().getModel("LocalModel").refresh();
            },

            // Method to cancel add record dialog
            onCancel: function () {
                this.getView().getModel("LocalModel").getProperty("/Operation").Value = "";
                this.getView().getModel("LocalModel").refresh();
                this.byId("_IDModifyDialog").close();
            },

            // Method to enable/disable the delete button
            onRowSelChange: function (oEvent) {
                if (oEvent.getSource().getSelectedIndices().length > 0) {
                    this.getView().byId("idDelete").setEnabled(true);
                } else {
                    this.getView().byId("idDelete").setEnabled(false);
                }
            },

            // Method to capture the changed value during editing mode for validations
            onRowChange: function (oEvt) {
                if (oEvt.getSource().getValue() === "") {
                    MessageBox.error(this._getText("mandatoryFields"));
                    oEvt.getSource().setValueState("Error");
                    oEvt.getSource().getBindingContext("LocalModel").getProperty("/Operation").BlankCell = true;
                } else if (oEvt.getSource().getId().split('--id')[1].split('-')[0] === "QuantityonEquipment") {
                    let sValue = oEvt.getSource().getValue();
                    if (sValue.split('.')[1].length > 6) {
                        oEvt.getSource().setValueState("Error");
                        oEvt.getSource().getBindingContext("LocalModel").getProperty("/Operation").BlankCell = true;
                        MessageBox.error(this._getText("decimalError"));
                    } else {
                        oEvt.getSource().setValueState("None");
                        oEvt.getSource().getBindingContext("LocalModel").getProperty("/Operation").BlankCell = false;
                    }
                } else {
                    oEvt.getSource().setValueState("None");
                    oEvt.getSource().getBindingContext("LocalModel").getProperty("/Operation").BlankCell = false;

                    if (oEvt.getSource().getBindingContext("LocalModel").getProperty("/Operation").Upload === "") {
                        oEvt.getSource().getBindingContext("LocalModel").getObject().message_type = "U";
                        oEvt.getSource().getBindingContext("LocalModel").getProperty("/Operation").Modify = "X";
                    }
                }
            },

            // Method to add the record in table for addition functionality
            onSave: function () {
                let sMessage = false, aTableData;
                sMessage = this._checkValidations(false);
                if (sMessage !== true) {
                    let oNewData = this.byId("_IDSmartForm").getBindingContext().getObject();
                    aTableData = this.getView().getModel("LocalModel").getProperty("/LoadData");
                    if (this.getView().getModel("LocalModel").getProperty("/Operation").Upload === "") {
                        oNewData.message_type = "C";
                        oNewData.flag_text = "X";
                        aTableData.push(oNewData);
                        this.getView().getModel("LocalModel").setProperty("/LoadData", aTableData);
                        this.getView().getModel("LocalModel").getProperty("/Operation").Create = "X";
                        this.getView().getModel("LocalModel").getProperty("/Operation").TableData = "X";
                        this.getView().getModel("LocalModel").refresh(true);
                    }
                    this.byId("_IDModifyDialog").close();
                }
            },

            // Method to delete records from table
            onDeleteRecord: function () {
                MessageBox.confirm(this._getText("deleteConfirmation"), {
                    title: "Confirm",
                    actions: [sap.m.MessageBox.Action.OK,
                    sap.m.MessageBox.Action.CANCEL],
                    emphasizedAction: sap.m.MessageBox.Action.OK,
                    onClose: function (oAction) {
                        if (oAction === "OK") {

                            let aIndices = this.getView().byId("_IDSmartInnerTable").getSelectedIndices(),
                                aTableData = this.getView().getModel("LocalModel").getProperty("/LoadData"),
                                aSelRecords = [], oPayload = {};
                            this.getView().setBusy(true);

                            // filtering records which are uploaded but not created and needed for deletion
                            if (this.getView().getModel("LocalModel").getProperty("/Operation").Upload === "X") {
                                aIndices.reverse();
                                aIndices.forEach((idx) => {
                                    aTableData.splice(idx, 1);
                                });
                            } else {
                                //filtering selected records which are created and needed for deletion
                                aIndices.forEach((idx) => {
                                    let oSelObj = this.getView().byId("_IDSmartInnerTable").getContextByIndex(idx).getObject();
                                    delete oSelObj.__metadata;
                                    aSelRecords.push(oSelObj);
                                });
                            }

                            if (aSelRecords.length > 0) {
                                //generating payload
                                oPayload.OPERATION = "D",
                                    oPayload.MSG_TYPE = "";
                                oPayload.MESSAGE = "",
                                    oPayload.LOAD_FACTOR = aSelRecords;

                                this._getODataModel().create("/ETS_HEADER", oPayload, {
                                    success: function (oData) {
                                        this.getView().setBusy(false);
                                        if (oData.MSG_TYPE === "S") {
                                            MessageBox.success(oData.MESSAGE);
                                            this.onSearch();
                                        } else {
                                            this._getMessagePopover(oData.LOAD_FACTOR.results);
                                            this.getView().getModel("LocalModel").getProperty("/Operation").Error = true;
                                            this.getView().getModel("LocalModel").getProperty("/Operation").Edit = false;
                                            this.getView().getModel("LocalModel").refresh(true);
                                        }
                                    }.bind(this),
                                    error: function (oError) {
                                        this.getView().setBusy(false);
                                        this.getView().getModel("LocalModel").getProperty("/Operation").Edit = false;
                                        var sPattern = new RegExp("[{}]");
                                        var sSstrMatch = oError.responseText.match(sPattern);
                                        if (sSstrMatch) {
                                            var sMsg = JSON.parse(oError.responseText);
                                            MessageBox.error(sMsg.error.message.value);
                                        } else {
                                            MessageBox.error(oError.responseText);
                                        }
                                    }.bind(this)
                                });
                            } else {
                                this.getView().getModel("LocalModel").setProperty("/LoadData", aTableData);
                                this.getView().getModel("LocalModel").refresh(true);
                                this.getView().setBusy(false);
                            }
                        }
                    }.bind(this)
                });
            },

            // Method to validate Quantity field
            onQunatity: function (oEvt) {
                var sPattern = new RegExp("[abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ]");
                var sStrMatch = oEvt.getParameters().value.match(sPattern);
                if (sStrMatch) {
                    MessageToast.show(this._getText("errorQunatity"));
                    oEvt.getSource().setValueState("Error");
                } else {
                    oEvt.getSource().setValueState("None");
                }
            },

            // Method to post data to backend for create/update/delete scenarios
            onExecute: function () {
                this.getView().setBusy(true);
                let oPayload = {}, aRecords = [];
                let aData = this.getView().getModel("LocalModel").getProperty("/LoadData");
                if (this.getView().getModel("LocalModel").getProperty("/Operation").Upload === "X") {
                    aData.forEach((item) => {
                        item.message_type = "C"
                    });
                    aRecords = aData;
                } else if (this.getView().getModel("LocalModel").getProperty("/Operation").Upload === "" && this.getView().getModel("LocalModel").getProperty("/Operation").Create === "X" && this.getView().getModel("LocalModel").getProperty("/Operation").Modify === "X") {
                    aRecords = aData.filter(item => item.message_type === "C" || item.message_type === "U");
                } else if (this.getView().getModel("LocalModel").getProperty("/Operation").Upload === "" && this.getView().getModel("LocalModel").getProperty("/Operation").Create === "X" && this.getView().getModel("LocalModel").getProperty("/Operation").Modify === "") {
                    aRecords = aData.filter(item => item.message_type === "C");
                } else if (this.getView().getModel("LocalModel").getProperty("/Operation").Upload === "" && this.getView().getModel("LocalModel").getProperty("/Operation").Create === "" && this.getView().getModel("LocalModel").getProperty("/Operation").Modify === "X") {
                    aRecords = aData.filter(item => item.message_type === "U");
                }

                if (this.getView().getModel("LocalModel").getProperty("/Operation").BlankCell !== true) {

                    if (this.getView().getModel("LocalModel").getProperty("/Operation").Error === true) {
                        this.getView().getModel("LocalModel").getProperty("/Operation").Error = false;
                    }

                    // generate payload to post data
                    oPayload.OPERATION = "M";
                    oPayload.MSG_TYPE = "";
                    oPayload.MESSAGE = "",
                        oPayload.LOAD_FACTOR = aRecords;

                    this._getODataModel().create("/ETS_HEADER", oPayload, {
                        success: function (oData) {
                            this.getView().setBusy(false);
                            if (oData.MSG_TYPE === "S") {
                                this.onSearch();
                                this.getView().getModel("LocalModel").getProperty("/Operation").Edit = false;
                                this.getView().getModel("LocalModel").getProperty("/Operation").Create = "";
                                this.getView().getModel("LocalModel").getProperty("/Operation").Modify = "";
                                this.getView().getModel("LocalModel").refresh(true);
                                this.getView().getModel("LocalModel").setProperty("/LoadData", oData.LOAD_FACTOR.results);
                                MessageBox.success(oData.MESSAGE);
                            } else if (oData.MSG_TYPE === "E") {
                                this._getMessagePopover(oData.LOAD_FACTOR.results);
                                this.getView().getModel("LocalModel").getProperty("/Operation").Error = true;
                                this.getView().getModel("LocalModel").getProperty("/Operation").Edit = false;
                                this.getView().getModel("LocalModel").setProperty("/LoadData", oData.LOAD_FACTOR.results);
                                this.getView().getModel("LocalModel").refresh(true);
                            }
                        }.bind(this),
                        error: function (oError) {
                            this.getView().setBusy(false);
                            this.getView().getModel("LocalModel").getProperty("/Operation").Edit = false;
                            var sPattern = new RegExp("[{}]");
                            var sSstrMatch = oError.responseText.match(sPattern);
                            if (sSstrMatch) {
                                var sMsg = JSON.parse(oError.responseText);
                                MessageBox.error(sMsg.error.message.value);
                            } else {
                                MessageBox.error(oError.responseText);
                            }
                        }.bind(this)
                    });
                } else {
                    this.getView().setBusy(false);
                    MessageBox.error(this._getText("mandatoryFields"));
                }
            },

            // Private method to get labels 
            _getText: function (param) {
                return this.getView().getModel("i18n").getResourceBundle().getText(param);
            },

            // Private method to get odata model reference
            _getODataModel: function () {
                return this.getOwnerComponent().getModel();
            },

            // Private method to get the dialog reference
            _openDialog: function () {
                if (!this.pDialog) {
                    this.pDialog = this.loadFragment({
                        name: "com.gpbp.zs2dlogtable.fragment.Modify"
                    });
                }
                this.pDialog.then(function (oDialog) {
                    oDialog.open();

                    let oBindingContext = this._getODataModel().createEntry("/zcdsv_s2d_LOAD_FACTOR");
                    this.byId("_IDSmartForm").bindElement(oBindingContext.getPath());

                }.bind(this));
            },

            // Private method to check for validations during add record functionality
            _checkValidations: function () {
                var oEntry = this.getView()
                    .byId("_IDSmartForm")
                    .getBindingContext()
                    .getObject();

                if (oEntry.OriginPlant === "" || oEntry.OriginPlant === undefined) {
                    MessageToast.show(this._getText("errorPlant"));
                    this.byId("_IDGenSmartField1").setValueState("Error");
                    return true;
                } else {
                    this.byId("_IDGenSmartField1").setValueState("None");
                }
                if (oEntry.ModeofTransportation === "" || oEntry.ModeofTransportation === undefined) {
                    MessageToast.show(this._getText("errorTransport"));
                    this.byId("_IDGenSmartField2").setValueState("Error");
                    return true;
                } else {
                    this.byId("_IDGenSmartField2").setValueState("None");
                }
                if (oEntry.ShipmentType === "" || oEntry.ShipmentType === undefined) {
                    MessageToast.show(this._getText("errorShipment"));
                    this.byId("_IDGenSmartField3").setValueState("Error");
                    return true;
                } {
                    this.byId("_IDGenSmartField3").setValueState("None");
                }
                if (oEntry.EquipmentType === "" || oEntry.EquipmentType === undefined) {
                    MessageToast.show(this._getText("errorEquipment"));
                    this.byId("_IDGenSmartField4").setValueState("Error");
                    return true;
                } else {
                    this.byId("_IDGenSmartField4").setValueState("None");
                }
                if (oEntry.ProductSku === "" || oEntry.ProductSku === undefined) {
                    MessageToast.show(this._getText("errorProduct"));
                    this.byId("_IDGenSmartField5").setValueState("Error");
                    return true;
                } else {
                    this.byId("_IDGenSmartField5").setValueState("None");
                }
            },

            // Private message to display error messages during upload/create 
            _getMessagePopover: function (data) {
                let aErroredRecords = data.filter(item => item.message_type === "E"),
                    aErrorMessages = [];
                if (aErroredRecords.length > 0) {
                    aErroredRecords.forEach((item) => {
                        let sMsgDescription = "Key Combination: " + item.OriginPlant + ", " + item.ModeofTransportation + ", " + item.ShipmentType + ", " + item.EquipmentType + ", " + item.ProductSku + " - " + item.message_text;
                        let oMessages = {
                            type: "Error",
                            title: "Error",
                            active: false,
                            description: sMsgDescription,
                            subtitle: item.OriginPlant + ", " + item.ModeofTransportation + ", " + item.ShipmentType + ", " + item.EquipmentType + ", " + item.ProductSku
                        };
                        aErrorMessages.push(oMessages);
                    });

                    this.getView().getModel("LocalModel").setProperty("/Messages", aErrorMessages);

                    let oMessageTemplate = new MessageItem({
                        type: '{LocalModel>type}',
                        title: '{LocalModel>title}',
                        activeTitle: "{LocalModel>active}",
                        description: '{LocalModel>description}',
                        subtitle: '{LocalModel>subtitle}',
                        counter: '{LocalModel>counter}',
                        markupDescription: true
                    });

                    oMessagePopover = new MessagePopover({
                        items: {
                            path: 'LocalModel>/Messages',
                            template: oMessageTemplate
                        },
                        activeTitlePress: function () {
                            //  MessageToast.show('Active title is pressed');
                        }
                    });

                    oMessagePopover.setAsyncDescriptionHandler(function (config) {
                        config.promise.resolve({
                            allowed: true,
                            id: config.id
                        });
                    });

                    this.getView().getModel("LocalModel").getProperty("/Operation").Error = true;
                    this.getView().getModel("LocalModel").refresh(true);
                    this.byId("_IDMessagePopoverBtn").addDependent(oMessagePopover);
                }
            },

            // Method to display errored messages
            onMessagePopoverPress: function (oEvt) {
                oMessagePopover.toggle(oEvt.getSource());
            },

            // Method to handle plant value help
            onPlantValueHelp: function (oEvt) {
                this.inputColumnId = oEvt.getSource().getId();
                this._oBasicSearchField = new SearchField();
                this.loadFragment({
                    name: "com.gpbp.zs2dlogtable.fragment.Plant"
                }).then(function (oDialog) {
                    var oFilterBar = oDialog.getFilterBar(), oColumnPlantCode, oColumnPlantName;
                    this._oVHD = oDialog;

                    this.getView().addDependent(oDialog);

                    // Set Basic Search for FilterBar
                    oFilterBar.setFilterBarExpanded(false);
                    oFilterBar.setBasicSearch(this._oBasicSearchField);

                    // Trigger filter bar search when the basic search is fired
                    this._oBasicSearchField.attachSearch(function () {
                        oFilterBar.search();
                    });

                    oDialog.getTableAsync().then(function (oTable) {

                        oTable.setModel(this.getOwnerComponent().getModel());
                        oTable.setSelectionMode("Single");

                        // For Desktop and tabled the default table is sap.ui.table.Table
                        if (oTable.bindRows) {
                            // Bind rows to the ODataModel and add columns
                            oTable.bindAggregation("rows", {
                                path: "/ZCDSV_S2D_LOADFACTOR_WERKS",
                                events: {
                                    dataReceived: function () {
                                        oDialog.update();
                                    }
                                }
                            });
                            oColumnPlantCode = new UIColumn({ label: new Label({ text: "Plant" }), template: new Text({ wrapping: false, text: "{werks}" }) });
                            oColumnPlantCode.data({
                                fieldName: "werks"
                            });
                            oColumnPlantName = new UIColumn({ label: new Label({ text: "Description" }), template: new Text({ wrapping: false, text: "{name1}" }) });
                            oColumnPlantName.data({
                                fieldName: "name1"
                            });
                            oTable.addColumn(oColumnPlantCode);
                            oTable.addColumn(oColumnPlantName);
                        }
                        oDialog.update();
                    }.bind(this));

                    oDialog.setTokens(this.getView().byId("idOriginPlant").getValue());
                    oDialog.open();
                }.bind(this));
            },

            // Event to handle OK button
            onValueHelpOkPress: function (oEvt) {
                this.getView().byId(this.inputColumnId).setValue(oEvt.getParameter("tokens")[0].getKey());
                this.getView().byId(this.inputColumnId).getParent().getBindingContext("LocalModel").getObject().message_type = "U";
                this.getView().byId(this.inputColumnId).getParent().getBindingContext("LocalModel").getProperty("/Operation").Modify = "X";
                this._oVHD.close();
            },

            // Event to handle Cancel button
            onValueHelpCancelPress: function () {
                this._oVHD.close();
            },

            // Event to handle After Close to destroy dialog
            onValueHelpAfterClose: function () {
                this._oVHD.destroy();
            },

            // Event to handle Search Plant
            onFilterBarSearch: function (oEvent) {
                var sSearchQuery = this._oBasicSearchField.getValue(),
                    aSelectionSet = oEvent.getParameter("selectionSet");

                var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
                    if (oControl.getValue()) {
                        aResult.push(new Filter({
                            path: oControl.getName(),
                            operator: FilterOperator.Contains,
                            value1: oControl.getValue()
                        }));
                    }

                    return aResult;
                }, []);

                aFilters.push(new Filter({
                    filters: [
                        new Filter({ path: "werks", operator: FilterOperator.Contains, value1: sSearchQuery }),
                        new Filter({ path: "name1", operator: FilterOperator.Contains, value1: sSearchQuery })
                    ],
                    and: false
                }));

                this._filterTable(new Filter({
                    filters: aFilters,
                    and: true
                }), this._oVHD);
            },

            // Private method to handle filters
            _filterTable: function (oFilter, VHD) {
                var oVHD = VHD;

                oVHD.getTableAsync().then(function (oTable) {
                    if (oTable.bindRows) {
                        oTable.getBinding("rows").filter(oFilter);
                    }
                    if (oTable.bindItems) {
                        oTable.getBinding("items").filter(oFilter);
                    }

                    // This method must be called after binding update of the table.
                    oVHD.update();
                });
            },

            // Method to handle product value help
            onMaterialValueHelp: function (oEvt) {
                this.inputMatColumnId = oEvt.getSource().getId();
                this._oBasicSearchField = new SearchField();
                this.loadFragment({
                    name: "com.gpbp.zs2dlogtable.fragment.Product"
                }).then(function (oDialog) {
                    var oFilterBar = oDialog.getFilterBar(), oColumnProductCode, oColumnPlantName;
                    this._oVHDM = oDialog;

                    this.getView().addDependent(oDialog);

                    // Set Basic Search for FilterBar
                    oFilterBar.setFilterBarExpanded(false);
                    oFilterBar.setBasicSearch(this._oBasicSearchField);

                    // Trigger filter bar search when the basic search is fired
                    this._oBasicSearchField.attachSearch(function () {
                        oFilterBar.search();
                    });

                    oDialog.getTableAsync().then(function (oTable) {

                        oTable.setModel(this.getOwnerComponent().getModel());
                        oTable.setSelectionMode("Single");

                        // For Desktop and tabled the default table is sap.ui.table.Table
                        if (oTable.bindRows) {
                            // Bind rows to the ODataModel and add columns
                            let sPlant = this.getView().byId(this.inputMatColumnId).getParent().getBindingContext("LocalModel").getObject().OriginPlant;
                            var aFilter = new Filter({ path: "werks", operator: FilterOperator.Contains, value1: sPlant });
                            oTable.bindAggregation("rows", {
                                path: "/ZCDSV_S2D_MATERIAL_PLANT_VH",
                                events: {
                                    dataReceived: function () {
                                        oDialog.update();
                                    }
                                }
                            });
                            oTable.getBinding().filter([aFilter]);
                            oColumnProductCode = new UIColumn({ label: new Label({ text: "Material" }), template: new Text({ wrapping: false, text: "{matnr}" }) });
                            oColumnProductCode.data({
                                fieldName: "matnr"
                            });
                            oColumnPlantName = new UIColumn({ label: new Label({ text: "Plant" }), template: new Text({ wrapping: false, text: "{werks}" }) });
                            oColumnPlantName.data({
                                fieldName: "werks"
                            });
                            oTable.addColumn(oColumnProductCode);
                            oTable.addColumn(oColumnPlantName);
                        }
                        oDialog.update();
                    }.bind(this));

                    oDialog.setTokens(this.getView().byId("idProductSku").getValue());
                    oDialog.open();
                }.bind(this));
            },

            // Event to handle Material OK button 
            onMatValueHelpOkPress: function (oEvt) {
                this.getView().byId(this.inputMatColumnId).setValue(oEvt.getParameter("tokens")[0].getKey());
                this.getView().byId(this.inputMatColumnId).getParent().getBindingContext("LocalModel").getObject().message_type = "U";
                this.getView().byId(this.inputMatColumnId).getParent().getBindingContext("LocalModel").getProperty("/Operation").Modify = "X";
                this._oVHDM.close();
            },

            // Event to handle Material Cancel button
            onMatValueHelpCancelPress: function () {
                this._oVHDM.close();
            },

            // Event to handle After Close to destroy dialog
            onMatValueHelpAfterClose: function () {
                this._oVHDM.destroy();
            },

            // Event to handle Material Search
            onMatFilterBarSearch: function (oEvent) {
                var sSearchQuery = this._oBasicSearchField.getValue(),
                    aSelectionSet = oEvent.getParameter("selectionSet");

                var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
                    if (oControl.getValue()) {
                        aResult.push(new Filter({
                            path: oControl.getName(),
                            operator: FilterOperator.Contains,
                            value1: oControl.getValue()
                        }));
                    }

                    return aResult;
                }, []);

                aFilters.push(new Filter({
                    filters: [
                        new Filter({ path: "matnr", operator: FilterOperator.Contains, value1: sSearchQuery }),
                        new Filter({ path: "werks", operator: FilterOperator.Contains, value1: sSearchQuery })
                    ],
                    and: false
                }));

                this._filterTable(new Filter({
                    filters: aFilters,
                    and: true
                }), this._oVHDM);
            },

            // Prive method to remove error state
            _removeErrorState: function () {
                let aRows = this.getView().byId("_IDSmartInnerTable").getRows();
                aRows.forEach((row) => {
                    let aCells = row.getCells();
                    aCells.forEach((cell) => {
                        if (cell instanceof sap.m.Input ||
                            cell instanceof sap.m.ComboBox) {
                            cell.setValueState("None");
                        }
                    });
                });
            }


        });
    });
