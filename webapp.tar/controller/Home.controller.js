sap.ui.define([
    "sap/ui/core/mvc/Controller"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller) {
        "use strict";

        return Controller.extend("com.gpbp.zs2dlogtable.controller.Home", {
            onInit: function () {

            },

            // function used to navigate to Load Factor table
            onLoadFactor: function (oEvt) {
                let oRouter = this.getOwnerComponent().getRouter();
                oRouter.navTo("RouteFactor");
            },

            // function used to navigate to Freight Multiplier table
            onFreightMultiplier: function () {
                var oCrossAppNavigator = sap.ushell.Container.getService(
                    "CrossApplicationNavigation"
                );
                var oHash =
                    oCrossAppNavigator &&
                    oCrossAppNavigator.hrefForExternal({
                        target: {
                            semanticObject: "LoadfactorFreightmultiplier",
                            action: "manage"
                        }
                    });

                oCrossAppNavigator.toExternal({
                    target: {
                        shellHash: oHash,
                    },
                });
            },

            // function used to navigate to Pure Capacity table
            onPureCapacity: function () {
                var oCrossAppNavigator = sap.ushell.Container.getService(
                    "CrossApplicationNavigation"
                );
                var oHash =
                    oCrossAppNavigator &&
                    oCrossAppNavigator.hrefForExternal({
                        target: {
                            semanticObject: "ZPURECAPACITY",
                            action: "manage"
                        }
                    });

                oCrossAppNavigator.toExternal({
                    target: {
                        shellHash: oHash,
                    },
                });
            }
        });
    });
